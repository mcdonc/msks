# Issue #649 retest — COMPLETED 2026-10-28/29 (post-kernel-upgrade)

## Outcome

**Still stalled on 7.2.12, and the fault is now isolated to the host kernel's
NV vGIC.** All three handoff knobs are resolved:

1. `kvm-arm.mode=1` — **void.** The Asahi tree accepts only
   `none|protected|nvhe|nested` (no numerics, no NV1/NV2 selector; FEAT_NV
   was dropped upstream). Booting with it yields
   `Malformed early option 'kvm-arm.mode'`. Arg removed via grubby.
   (Possible extra knob for the report: `kvm-arm.wfi_trap_policy=trap` /
   `wfe_trap_policy=trap` — exists in-tree, default `notrap,single-task`;
   requires a reboot; NOT run.)
2. Newer cloud-hypervisor — **void.** v54.0 (2026-10-14) is the newest
   release; the shipped pin is already latest.
3. QEMU A/B — **done, decisive.** QEMU 10.2.2 (`-M virt,gic-version=3
   -cpu host -accel kvm`, same kernel/initrd/cmdline/rootfs-backing, 2 vCPU/
   8 GiB, user-net) reproduces the identical failure: hard LOCKUP on cpu 0
   at t=24.0s during virtio_blk/ext4 module load, console silent after.
   Two independent VMMs, same host kernel, same instant → host KVM NV vGIC.

## Evidence matrix

| Variant | Result |
| --- | --- |
| CH 54.0 + 7.1.6 | LOCKUP cpu 0 @ 24.0s (baseline) |
| CH 54.0 + 7.2.12 | rcu stall @ 21.8s, LOCKUP cpu 0 @ 31.8s, hung tasks @ 244s, 503 shutdown deadline |
| QEMU 10.2.2 + 7.2.12 | LOCKUP cpu 0 @ 24.0s, identical modules/signature |

## Artifacts (this directory)

- `baseline-7.1.6-CH54.log` — original baseline
- `boot-20261028-225734.log` — 7.2.12 + CH (early-capture; its "BOOTED"
  verdict was a script false positive, fixed in `retest.sh`)
- `boot-full-225908.log` — 7.2.12 + CH, full capture (the CH-side evidence)
- `qemu-boot-20261028-232449.log` + `qemu-ab.sh` — QEMU A/B evidence + repro
- `asahi-report-draft.md` — draft AsahiLinux/linux report (not yet filed)

Issue #649 holds the results: issuecomment-6487145844. The doctor warning
row (#650) and the docs section stay in place.

## Remaining step (human decision)

File `asahi-report-draft.md` on AsahiLinux/linux (public action — posted
only with owner approval). Retest trigger stays: re-run `retest.sh` after
each Asahi kernel update; BOOTED retires the issue + doctor row + docs.

## Ops notes

- `qemu-system-aarch64` (KVM-capable) had to be installed; the
  `qemu-system-arm` binary Fedora ships here is TCG-only.
- msksd does not auto-start after reboot; start it, then run:
  `devenv --quiet shell -- bash /home/chrism/649-retest/retest.sh`
