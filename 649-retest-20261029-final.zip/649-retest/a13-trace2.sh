#!/usr/bin/env bash
# a13 (a09 round 2): trace guest sysreg reads during the stall.
# Question: does the guest read ICC_IAR1 (and get spurious), or never
# read it (pending never signaled)? Event set = a09 + kvm_handle_sys_reg.
# NOTE: no vgic-state sampler — this kernel exposes no per-VM KVM debugfs
# entries (verified live: /sys/kernel/debug/kvm holds global stats only).
set -u
T=/sys/kernel/tracing
HERE=/home/chrism/649-retest
STAMP=$(date +%Y%m%d-%H%M%S)
TRACE="$HERE/logs/a13-trace-$STAMP.txt"
DIGEST="$HERE/logs/a13-digest-$STAMP.txt"

EVENTS="kvm_ack_irq kvm_irq_line kvm_timer_update_irq kvm_wfx_arm64 \
vgic_update_irq_pending kvm_handle_sys_reg"

sudo bash -c "
  echo 0 > $T/tracing_on
  echo > $T/trace
  echo 0 > $T/events/enable
  for e in $EVENTS; do echo 1 > $T/events/kvm/\$e/enable 2>/dev/null; done
  echo 1 > $T/tracing_on
  echo \"armed: tracing_on=\$(cat $T/tracing_on)\"
"

echo "=== running qemu-ab.sh (KVM) under trace ==="
ACCEL=kvm CPU=host WATCH_SECS=240 bash "$HERE/qemu-ab.sh" 2>&1 | grep -vE "^•|^✓|^✨"

sudo bash -c "echo 0 > $T/tracing_on; echo 0 > $T/events/enable; cp $T/trace '$TRACE'"
sudo chown chrism:chrism "$TRACE" 2>/dev/null

{
  echo "# a13 digest $STAMP"
  echo "## total trace events: $(wc -l < "$TRACE")"
  for e in $EVENTS; do printf "%-26s %s\n" "$e" "$(grep -c " $e:" "$TRACE")"; done
  echo
  echo "## guest sysreg reads seen by KVM (kvm_handle_sys_reg), by register"
  grep " kvm_handle_sys_reg:" "$TRACE" | grep -ioE "(ICC|CNTP|CNTV|CNTH|PMR)[A-Z0-9_]*" | sort | uniq -c | sort -rn | head -10
  echo
  echo "## IAR/EOI-specific lines (capped 15)"
  grep -iE " kvm_handle_sys_reg:.*(IAR|EOI)" "$TRACE" | head -15
  echo
  echo "## last 10 vgic pending asserts (capped)"
  grep " vgic_update_irq_pending:" "$TRACE" | tail -10
  echo
  echo "## wfx distinct PCs (top 4)"
  grep " kvm_wfx_arm64:" "$TRACE" | sed -E 's/.*(wfi|wfe) at: (\S+).*/\1 @ \2/' | sort | uniq -c | sort -rn | head -4
  echo
  echo "## (vgic-state sampler unavailable: kernel has no per-VM KVM debugfs entries)"
} > "$DIGEST"

echo "=== digest ==="
cat "$DIGEST"
echo "=== full trace: $TRACE ==="
