# a09 findings — KVM trace during the stall (2026-10-29, host 7.2.12-402, wfi_trap_policy=trap live)

Trace: a09-trace-rescued.txt (205,859 events). Guest stalled as usual
(hard LOCKUP at guest t=24.0s; this run cpu 1 reported, cpu 0 sent NMI).

## The pattern: timer IRQ asserted, never delivered

- `kvm_timer_update_irq` 38,374 / `vgic_update_irq_pending` 38,771 — the
  host asserts the arch-timer PPI (INTID 27; 30 toggles alongside) pending
  on the vCPU essentially continuously once the stall begins.
- `kvm_ack_irq` 0 — no guest interrupt-ACK activity traced at all.
- `kvm_wfx_arm64` 85,571 — two distinct guest PCs:
  - 36,262 × `wfi @ 0xffffe2e5d7939f24`
  - 49,309 × `wfe @ 0xffffe2e5d78f14dc`
- Final phase = livelock: one vCPU thread (host CPU 006) re-executes WFI
  at the same guest PC every ~1.5µs while the vgic re-asserts IRQ 27
  pending at ~700k/s (2,000 asserts in the last 2.8ms of trace).
  Both vCPU threads show IRQ 27 assertions (VCPU 0 early at t≈312s wall,
  VCPU 1 in the final storm).

Reading: KVM decides the pending timer IRQ should wake the vCPU (hence the
wake/re-enter/WFI loop under trap policy), but the guest never observes
the interrupt — its CPU interface never presents IRQ 27 (an IAR read
presumably returns 1023/spurious). Delivery-side failure of the emulated
GICv3 CPU interface on the NV sysreg-trapping path, consistent with the
kvmarm vgic fold/flush repair series in flight (2026-09 v2, Cc stable).

Caveat: captured with `kvm-arm.wfi_trap_policy=trap` (attempt a01). Under
the default policy the vCPU sleeps instead of spinning, but the failure
signature (timer asserted, tick never resumes, rcu `0 ticks this GP`) is
identical in every default-policy console capture.
