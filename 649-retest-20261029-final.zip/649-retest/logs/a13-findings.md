# a13 findings — round 2 trace, DEFAULT policy boot (2026-10-29, host 7.2.12-402)

Boot state: kvm-arm.mode=nested (inert, see a04), wfi_trap_policy reverted
to default notrap,single-task. Guest stalled as usual: hard LOCKUP cpu 0 at
guest t=24.001s, console silent after.

Trace: a13-trace-20261029-001522.txt, 208,160 events.

## The answer: the guest never reads IAR — it never sees the interrupt

- `vgic_update_irq_pending`: 69,928 — IRQ 27 (arch timer PPI), level 1,
  VCPU 0, for the whole stall (~700k/s peak; 10 events in the final 12µs).
- `kvm_timer_update_irq`: 69,619 — host re-asserts the timer continuously.
- `kvm_wfx_arm64`: 68,219 — ALL of them `wfi` at ONE guest PC (the idle
  loop), i.e. the vCPU re-enters WFI in a tight loop *under the default
  policy too*: KVM wakes it ("pending timer → must run"), re-enters the
  guest, the guest sees nothing, WFIs again.
- `kvm_handle_sys_reg`: 70 events TOTAL for the entire boot — and the
  register breakdown contains **zero ICC_*, zero IAR/EOI, zero CNTP_***
  reads. The guest never acknowledges (or even polls for) an interrupt
  during the stall; it isn't even re-programming the timer — it is parked
  in the idle loop waiting for the IRQ it programmed before the stall.
- `kvm_ack_irq`: 0.

Conclusion (with a09): KVM asserts the vtimer pending into the vgic ~70k
times, its wake logic runs (the WFI re-entry loop), but the pending state
is never presented to the guest's emulated GICv3 CPU interface — the guest
takes no interrupt ever again, its tick dies, rcu starves, watchdog NMI at
t=24.0s. The break is in the vgic pending→signaling step (fold into list
registers / CPU-interface presentation) of the NV sysreg-trapping path
(`GICv3 sysreg trapping enabled ([C])`), matching the kvmarm vgic
fold/flush repair series in flight (2026-09 v2, Cc stable).

Variants seen: one earlier run (20261029-000954) hung silent from guest
t≈0.4s with no lockup within 240s — same family as the recorded 1-vCPU
"silent pre-userspace" variant; the 24.0s LOCKUP variant is the norm.

Sampler note: per-vCPU vgic-state debugfs files do not exist on this
kernel (only global KVM stats under /sys/kernel/debug/kvm), so the
distributor/LR state could not be sampled directly; the sysreg trace
carries the answer instead.
