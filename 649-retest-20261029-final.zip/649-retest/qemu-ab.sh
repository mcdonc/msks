#!/usr/bin/env bash
# Issue #649, knob 3: QEMU A/B against cloud-hypervisor with the same
# guest kernel/initrd/cmdline/rootfs backing (fresh overlay), 2 vCPU /
# 8 GiB / GICv3 / KVM.  CH 54.0 on this host: vCPU-0 timer death at ~24s.
set -u

ACCEL=${ACCEL:-kvm}
CPU=${CPU:-host}
# a06 A/B overrides: newer guest kernel / different rootfs (same cmdline)
KERNEL=${KERNEL:-/home/chrism/projects/msks/.devenv/state/msksd/images/008b3c91d4faad3b30b63c7e184617bc25d406113647653b3be4a9dfe925b273/kernel}
INITRD=${INITRD:-/home/chrism/projects/msks/.devenv/state/msksd/images/008b3c91d4faad3b30b63c7e184617bc25d406113647653b3be4a9dfe925b273/initrd}
ROOTFS=${ROOTFS:-/home/chrism/projects/msks/.devenv/state/msksd/images/008b3c91d4faad3b30b63c7e184617bc25d406113647653b3be4a9dfe925b273/rootfs.ext4}
IMGDIR=/home/chrism/projects/msks/.devenv/state/msksd/images/008b3c91d4faad3b30b63c7e184617bc25d406113647653b3be4a9dfe925b273
VMDIR=/home/chrism/projects/msks/.devenv/state/msksd/vms/f913d57fef
HERE=/home/chrism/649-retest
STAMP=$(date +%Y%m%d-%H%M%S)
LOG="$HERE/qemu-boot-$STAMP.log"
OUT="$HERE/qemu-stdout-$STAMP.log"
PIDFILE="$HERE/qemu.pid"

qemu-img create -f qcow2 -b "$ROOTFS" -F raw "$HERE/qemu-ab-overlay.qcow2" 10G >/dev/null

setsid qemu-system-aarch64 \
  -M virt,gic-version=3 -cpu $CPU -accel $ACCEL \
  -smp 2 -m 8192 \
  -kernel "$KERNEL" -initrd "$INITRD" \
  -append "console=ttyAMA0 root=/dev/vda rootfstype=ext4 rw" \
  -drive file="$HERE/qemu-ab-overlay.qcow2",if=virtio,format=qcow2 \
  -drive file="$VMDIR/seed.img",if=virtio,format=raw,readonly=on \
  -netdev user,id=n0 -device virtio-net-pci,netdev=n0 \
  -display none -monitor none -serial file:"$LOG" \
  >"$OUT" 2>&1 &
QPID=$!
echo "$QPID" > "$PIDFILE"

DEADLINE=$((SECONDS + ${WATCH_SECS:-420}))
VERDICT=unknown
while [ $SECONDS -lt $DEADLINE ]; do
    sleep 15
    kill -0 "$QPID" 2>/dev/null || { VERDICT=QEMU-DIED; break; }
    if grep -qiE "sshd|login:|Reached target (multi-user|graphical)" "$LOG" 2>/dev/null; then VERDICT=BOOTED; break; fi
    if grep -qE "hard LOCKUP|rcu.*stall|hung_task|INFO: task" "$LOG" 2>/dev/null; then
        if ! grep -qiE "sshd|login:|Reached target (multi-user|graphical)" "$LOG"; then VERDICT=STALLED; break; fi
    fi
done

echo "=== verdict: $VERDICT (after $SECONDS s, accel=$ACCEL cpu=$CPU) ==="
wc -c "$LOG" 2>/dev/null
echo "--- markers ---"
grep -icE "systemd" "$LOG" 2>/dev/null || true
grep -iE "dhcp|sshd|login:|Reached target (multi-user|graphical)" "$LOG" 2>/dev/null | head -8
echo "--- failure markers (count) ---"
grep -cE "hard LOCKUP|rcu_preempt|hung task|Call trace" "$LOG" 2>/dev/null || true
echo "--- tail ---"
tail -c 400 "$LOG" 2>/dev/null | tr -d '\r'

kill -- -"$QPID" 2>/dev/null
sleep 2
pkill -x qemu-system-aarch64 2>/dev/null
echo "=== console log: $LOG ==="
