#!/usr/bin/env bash
# a09: capture KVM timer/vgic tracepoints while a guest stalls (issue #649).
# Runs the QEMU/KVM A/B (self-contained, no msksd) under a focused tracefs set,
# then saves the trace + a digest. Event meanings:
#   kvm_timer_emulate/_hrtimer_expire/_update_irq  host-side emulated ptimer
#   vgic_update_irq_pending                        IRQ asserted into the vgic
#   kvm_ack_irq                                    guest ACK of an IRQ
#   kvm_wfx_arm64                                  WFI/WFE traps (this boot: wfi_trap_policy=trap)
#   kvm_irq_line/kvm_set_irq                       device IRQs (virtio)
set -u
T=/sys/kernel/tracing
HERE=/home/chrism/649-retest
STAMP=$(date +%Y%m%d-%H%M%S)
TRACE="$HERE/logs/a09-trace-$STAMP.txt"
DIGEST="$HERE/logs/a09-digest-$STAMP.txt"

EVENTS="kvm_ack_irq kvm_forward_sysreg_trap kvm_get_timer_map kvm_inject_nested_exception \
kvm_irq_line kvm_set_irq kvm_timer_emulate kvm_timer_hrtimer_expire kvm_timer_restore_state \
kvm_timer_save_state kvm_timer_update_irq kvm_wfx_arm64 vgic_update_irq_pending"

sudo bash -c "
  echo 0 > $T/tracing_on
  echo > $T/trace
  echo 0 > $T/events/enable
  for e in $EVENTS; do echo 1 > $T/events/kvm/\$e/enable 2>/dev/null; done
  cat $T/set_event_pid > $HERE/logs/.set_event_pid.bak 2>/dev/null || true
  echo 1 > $T/events/kvm/kvm_wfx_arm64/enable
  echo 1 > $T/tracing_on
"

echo "=== running qemu-ab.sh (KVM) under trace ==="
ACCEL=kvm CPU=host WATCH_SECS=240 bash "$HERE/qemu-ab.sh" 2>&1 | grep -vE "^•|^✓|^✨"

sudo bash -c "echo 0 > $T/tracing_on; echo 0 > $T/events/enable; cp $T/trace '$TRACE'"

{
  echo "# a09 trace digest $STAMP"
  echo "## total events: $(wc -l < "$TRACE")"
  for e in $(echo $EVENTS); do
    printf "%-28s %s\n" "$e" "$(grep -c " $e:" "$TRACE")"
  done
  echo
  echo "## last 40 vgic/timer events before trace end"
  grep -E " (vgic_update_irq_pending|kvm_timer_update_irq|kvm_timer_hrtimer_expire|kvm_timer_emulate|kvm_ack_irq):" "$TRACE" | tail -40
} > "$DIGEST"

echo "=== digest ==="
cat "$DIGEST"
echo "=== full trace: $TRACE ==="
