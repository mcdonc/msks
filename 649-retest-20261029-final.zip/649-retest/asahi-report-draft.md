# KVM guests on Apple Silicon: vCPU 0 hard LOCKUP ~24s into boot (timer/interrupt delivery dies under NV vGIC)

> Draft — review before filing on https://github.com/AsahiLinux/linux/issues

## Summary

On an M3 host (Fedora Asahi Remix 44, kernel-16k 7.2.12-402.asahi.fc44,
KVM NV mode with the non-architected vgic: `GICv3 sysreg trapping enabled`,
`GIC system register CPU interface enabled`), aarch64 Linux guests boot deep
and then die: at ~21–24s into boot, during virtio_blk/ext4 module load and
first systemd writes, vCPU 0 stops receiving interrupts. Its tick goes to
zero, rcu_sched starves, the NMI watchdog fires `Watchdog detected hard
LOCKUP on cpu 0`, and all block IO (jbd2 commits, ext4lazyinit) hangs past
the 120s hung-task threshold. No DHCP/sshd/login. The guest also ignores
GPIO/ACPI shutdown afterwards.

**This reproduces identically under two independent VMMs** — cloud-
hypervisor 54.0 and QEMU 10.2.2 — with the same kernel/initrd/cmdline/
rootfs, same 2 vCPU/8 GiB topology, GICv3, KVM. Same failure instant
(t=24.0s), same signature. That points at the kernel's NV vGIC emulation,
not at either VMM's device model.

Also reproduced on kernel 7.1.6-400.asahi.fc44 (same signature). cloud-
hypervisor 52.0 was strictly worse (lockup at ~24s with less boot depth);
54.0 is the current latest release.

## Environment

- Host: Apple M3 (fedoramac), Fedora Asahi Remix 44,
  `7.2.12-402.asahi.fc44.aarch64+16k`
- Host KVM init: `nv: 570 coarse / 710 fine grained trap handlers`,
  `Non-architectural vgic, tainting kernel`, `GICv3: no GICV resource entry`,
  `GICv3 sysreg trapping enabled ([C], reduced performance)`,
  `GIC system register CPU interface enabled`, `VHE mode initialized
  successfully`
- Guest: Debian 13.6 cloud image, kernel `6.12.107+deb13-arm64-16k`
  (16K pages), direct kernel boot, `console=ttyAMA0 root=/dev/vda
  rootfstype=ext4 rw`, 2 vCPU, 8 GiB
- VMMs: cloud-hypervisor 54.0 (virtio-blk qcow2 overlay on raw ext4
  backing, virtio-net via tap) and QEMU 10.2.2
  (`-M virt,gic-version=3 -cpu host -accel kvm`, virtio drives, user-net)

## Failure signature (identical in both VMMs)

```
[   21.751763] rcu: INFO: rcu_sched detected stalls on CPUs/tasks:
[   21.752082] rcu: 	0-...!: (0 ticks this GP) idle=df88/0/0x0 softirq=1219/1219 fqs=0 (false positive?)
[   21.752856] Sending NMI from CPU 1 to CPUs 0:
[   31.755083] rcu: 	Possible timer handling issue on cpu=0 timer-softirq=66
[   31.758562] watchdog: Watchdog detected hard LOCKUP on cpu 0
[   31.758840] Modules linked in: virtio_net net_failover failover nft_ct ... virtio_blk ext4 jbd2 mbcache crc32c_generic crc16
[  244.020790] INFO: task kworker/0:1:10 blocked for more than 122 seconds.
[  244.024469] INFO: task jbd2/vda-8:147 blocked for more than 122 seconds.
[  244.028235] INFO: task ext4lazyinit:149 blocked for more than 122 seconds.
```

(QEMU run: `Watchdog detected hard LOCKUP on cpu 0` at exactly t=24.0s,
`Modules linked in: virtio_blk ext4 jbd2 mbcache crc32c_generic crc16`,
console silent afterwards.)

Guest-side `irqpoll nohz=off` makes no difference — device IRQ polling
cannot resurrect a CPU whose tick is gone.

## Reproducers

- cloud-hypervisor 54.0: standard CH REST `vm.create` (payload
  kernel/initrd/cmdline as above; serial socket), boots to the lockup every
  time.
- QEMU 10.2.2:
  ```
  qemu-system-aarch64 -M virt,gic-version=3 -cpu host -accel kvm \
    -smp 2 -m 8192 \
    -kernel <Image> -initrd <initrd> \
    -append "console=ttyAMA0 root=/dev/vda rootfstype=ext4 rw" \
    -drive file=overlay.qcow2,if=virtio,format=qcow2 \
    -netdev user,id=n0 -device virtio-net-pci,netdev=n0 \
    -display none -serial file:console.log
  ```
  (fresh qcow2 overlay on the same ext4 rootfs; fails at 24.0s)

Full console logs available: three captures (CH+7.1.6, CH+7.2.12, QEMU+
7.2.12) — happy to attach.

## What we checked

- **Not the VMM: two independent VMMs, identical failure (above).**
- **Not the guest stack: the same rootfs/kernel/cmdline BOOTS TO COMPLETION
  under QEMU TCG** (pure emulation, no KVM) on this same machine — sshd
  listening, all services up, zero failure markers.
- Not the guest image: same rootfs boots to completion on non-Asahi arm64
  hosts.
- `kvm-arm.mode` numerics don't exist on this kernel (only
  `none|protected|nvhe|nested`), so an NV1-vs-NV2 A/B wasn't possible;
  `Malformed early option 'kvm-arm.mode'` if attempted.
- Host 7.1.6 → 7.2.12: no change. `kvm-arm.wfi_trap_policy=trap`: no change
  to the outcome.

## What the host trace shows (pending, never presented)

Two tracefs captures (205k and 208k events) during stalled QEMU/KVM boots —
round 1 under `wfi_trap_policy=trap`, round 2 under the default policy;
identical conclusions:

- The host asserts the guest arch-timer PPI (INTID 27) pending ~70k times
  per run (vgic_update_irq_pending 69,928; kvm_timer_update_irq 69,619),
  level 1, on the vCPU that dies.
- KVM's wake logic runs: the vCPU re-enters WFI at the same idle-loop PC
  68k times — woken for the "pending" timer, guest sees nothing, sleeps
  again (a livelock under trap policy; same loop, slower burn, under
  default).
- Crucially, `kvm_handle_sys_reg` shows 70 trapped sysreg accesses for the
  ENTIRE boot — **zero ICC_IAR1/ICC_EOIR1 reads and zero CNTP_* accesses
  during the stall**: the guest never acknowledges, polls for, or
  re-programs an interrupt again. From inside the guest, no interrupt was
  ever signaled.
- `kvm_ack_irq` never fires; guest-side `irqpoll nohz=off` makes no
  difference.

So: pending state is asserted and the wake path fires, but the emulated
GICv3 CPU interface never presents the interrupt to the guest — the
break is in the vgic pending→signaling step (list-register fold /
CPU-interface presentation) on the NV sysreg-trapping path
(`GICv3 sysreg trapping enabled ([C])`).

Happy to run any further experiments on this machine (extra knobs,
instrumented kernels, bisection candidates).
