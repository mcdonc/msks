# Issue #649 handoff — GENERATED 2026-10-29T02:16:03 by handoff.sh status --write (do not edit by hand)

Fault: guest vCPU-0 hard LOCKUP ~24s into boot; reproduced CH 54.0 AND QEMU 10.2.2
(VMM-independent) on host KVM NV vGIC. Evidence bundle: issue #649 comment +
issue-649-assets branch. Narrative history: ARCHIVE-handoff-2026-10-28.md.

## Current phase
- No host knob applied. Next: `bash /home/chrism/649-retest/handoff.sh next`
- NOTE: msksd NOT reachable at https://127.0.0.1:8661/ — start the devenv server before testing

| id | status | title | note |
| --- | --- | --- | --- |
| a01 | reverted | host knob: kvm-arm.wfi_trap_policy=trap | tested — reverted 2026-10-29T00:03:28 |
| a02 | done | host knob: kvm-arm.wfe_trap_policy=trap | VOID — a01 showed trapping WFI changes nothing (LOCKUP at t=24.009s, byte-identical timing); WFE trapping adds nothing f |
| a03 | done | host knob: wfi+wfe trap combined | VOID — superseded by a01 result |
| a04 | done | host knob: kvm-arm.mode=nested (explicit) | STALLED — LOCKUP t=24.012s — explicit mode=nested is behaviorally inert (as predicted) |
| a05 | reverted | host knob: kvm.enable_virt_at_load=1 | done — reverted 2026-10-29T00:38:05 |
| a06 | done | guest A/B: Debian 7.2.13+deb14-arm64-16k kernel, same rootfs | STALLED — Debian 7.2.13+deb14-arm64-16k guest (same rootfs copy): LOCKUP cpu1 @16s, NMI ignored 10s — guest vintage irre |
| a07 | tested | control: same rootfs under QEMU TCG (no KVM) | BOOTED |
| a08 | done | VMM A/B: cloud-hypervisor built from main | STALLED — CH main v55.0.0 (84bca7b 2026-10-28): same LOCKUP cpu0 @31.2s — no post-54 vgic rescue; VMM exonerated across  |
| a09 | done | diagnostic: KVM/vgic tracepoints during a stall | DIAGNOSTIC — timer INTID 27 asserted ~38k x (vgic_update_irq_pending) with 0 kvm_ack_irq; WFI/WFE livelock at same guest |
| a10 | done | kernel: test the Asahi branch TIP (originally: backport 2026-09 vgic series) | STALLED — AsahiLinux/linux asahi@94fb23346 (7.1.13-asahitip+, canonical tree, 16k config from 402): hard LOCKUP cpu0 @24 |
| a11 | pending | process: file the AsahiLinux/linux report |  |
| a12 | pending | process: cross-post QEMU A/B to Fedora discussion t/179358 |  |
| a13 | done | diagnostic round 2: IAR-read trace + vgic-state sampler | DIAGNOSTIC — guest NEVER reads ICC_IAR1 (70 sysreg traps total, 0 ICC/CNTP): interrupt never presented — vgic pending->s |
| h01 | done | kernel 7.2.12-402 + CH 54.0 retest | STALLED — rcu stall 21.8s, hard LOCKUP cpu0 31.8s, hung tasks 244s; log boot-full-225908.log |
| h02 | done | knob 1: kvm-arm.mode=1 (force NV1) | VOID — kvm-arm.mode=1 nonexistent (only none|protected|nvhe|nested); FEAT_NV dropped; arg removed |
| h03 | done | knob 2: newer cloud-hypervisor | VOID — CH v54.0 is the newest release; pin already latest |
| h04 | done | knob 3: QEMU 10.2.2 A/B, same rootfs | STALLED — identical LOCKUP cpu0 t=24.0s under QEMU -> host KVM NV vGIC; log qemu-boot-20261028-232449.log |

## Results so far
id   stamp                host_kernel                        variant                                                                       verdict  seconds  log
h01  2026-10-28T23:47:38  7.2.12-402.asahi.fc44.aarch64+16k  kernel 7.2.12-402 + CH 54.0 retest                                            STALLED  -        rcu stall 21.8s, hard LOCKUP cpu0 31.8s, hung tasks 244s; log boot-full-225908.log
h02  2026-10-28T23:47:38  7.2.12-402.asahi.fc44.aarch64+16k  knob 1: kvm-arm.mode=1 (force NV1)                                            VOID     -        kvm-arm.mode=1 nonexistent (only none|protected|nvhe|nested); FEAT_NV dropped; arg removed
h03  2026-10-28T23:47:38  7.2.12-402.asahi.fc44.aarch64+16k  knob 2: newer cloud-hypervisor                                                VOID     -        CH v54.0 is the newest release; pin already latest
h04  2026-10-28T23:47:38  7.2.12-402.asahi.fc44.aarch64+16k  knob 3: QEMU 10.2.2 A/B, same rootfs                                          STALLED  -        identical LOCKUP cpu0 t=24.0s under QEMU -> host KVM NV vGIC; log qemu-boot-20261028-232449.log
a01  20261028-235241      7.2.12-402.asahi.fc44.aarch64+16k  host knob: kvm-arm.wfi_trap_policy=trap                                       STALLED  41       /home/chrism/649-retest/logs/a01-20261028-235241.out
a02  2026-10-28T23:54:17  7.2.12-402.asahi.fc44.aarch64+16k  host knob: kvm-arm.wfe_trap_policy=trap                                       VOID     -        a01 showed trapping WFI changes nothing (LOCKUP at t=24.009s, byte-identical timing); WFE trapping adds nothing for timer wake
a03  2026-10-28T23:54:17  7.2.12-402.asahi.fc44.aarch64+16k  host knob: wfi+wfe trap combined                                              VOID     -        superseded by a01 result
a07  20261028-235420      7.2.12-402.asahi.fc44.aarch64+16k  control: same rootfs under QEMU TCG (no KVM)                                  BOOTED   30       /home/chrism/649-retest/logs/a07-20261028-235420.out
a09  20261028-235606      7.2.12-402.asahi.fc44.aarch64+16k  diagnostic: KVM/vgic tracepoints during a stall                               STALLED  30       /home/chrism/649-retest/logs/a09-20261028-235606.out
a04  20261029-000524      7.2.12-402.asahi.fc44.aarch64+16k  host knob: kvm-arm.mode=nested (explicit)                                     STALLED  41       /home/chrism/649-retest/logs/a04-20261029-000524.out
a13  20261029-000715      7.2.12-402.asahi.fc44.aarch64+16k  diagnostic round 2: IAR-read trace + vgic-state sampler                       STALLED  30       /home/chrism/649-retest/logs/a13-20261029-000715.out
a13  20261029-000954      7.2.12-402.asahi.fc44.aarch64+16k  diagnostic round 2: IAR-read trace + vgic-state sampler                       UNKNOWN  240      /home/chrism/649-retest/logs/a13-20261029-000954.out
a13  20261029-001522      7.2.12-402.asahi.fc44.aarch64+16k  diagnostic round 2: IAR-read trace + vgic-state sampler                       STALLED  30       /home/chrism/649-retest/logs/a13-20261029-001522.out
a08  20261029-002400      7.2.12-402.asahi.fc44.aarch64+16k  VMM A/B: cloud-hypervisor built from main                                     UNKNOWN  ?        /home/chrism/649-retest/logs/a08-20261029-002400.out
a08  20261029-002517      7.2.12-402.asahi.fc44.aarch64+16k  VMM A/B: cloud-hypervisor built from main                                     STALLED  41       /home/chrism/649-retest/logs/a08-20261029-002517.out
a06  20261029-002914      7.2.12-402.asahi.fc44.aarch64+16k  guest A/B: Debian 7.2.13+deb14-arm64-16k kernel, same rootfs                  STALLED  30       /home/chrism/649-retest/logs/a06-20261029-002914.out
a05  20261029-003651      7.2.12-402.asahi.fc44.aarch64+16k  host knob: kvm.enable_virt_at_load=1                                          STALLED  41       /home/chrism/649-retest/logs/a05-20261029-003651.out
a10  20261029-021429      7.1.13-asahitip+                   kernel: test the Asahi branch TIP (originally: backport 2026-09 vgic series)  STALLED  41       /home/chrism/649-retest/logs/a10-20261029-021429.out

## Ops notes (hard-won)
- msksd does NOT auto-start after reboot; probe: https://127.0.0.1:8661/
- retests run as: cd ~/projects/msks && devenv --quiet shell -- bash /home/chrism/649-retest/retest.sh
- qemu: use qemu-system-aarch64 (KVM-capable); Fedora's qemu-system-arm is TCG-only
- NEVER pkill -f with a pattern your own shell contains — pkill -x <bin> only
- BOOTED requires sshd/login/multi-user markers; 'Reached target' alone is a false positive
- GitHub attachments via API are media-only; archives ride the issue-649-assets branch

## Standing trigger
- After each kernel-16k update: re-run retest.sh; BOOTED retires the issue, doctor row, docs.
