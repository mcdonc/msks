#!/usr/bin/env bash
# Issue #649 retest: boot workspace `asd` and capture the guest console.
# Run from the msks repo:  devenv --quiet shell -- bash /home/chrism/649-retest/retest.sh
#
# Baseline (kernel 7.1.6-400, CH 54.0, captured 2026-10-28): hard LOCKUP on
# cpu 0 at t=24s during module load; console silent after; no systemd/DHCP/
# sshd. Log: /home/chrism/649-retest/baseline-7.1.6-CH54.log
set -u

REPO=/home/chrism/projects/msks
# WORKSPACE lets A/B attempts (a06: newer guest kernel) target a second
# workspace; the VM dir is resolved from its id so the id hash isn't hardcoded.
WORKSPACE=${WORKSPACE:-asd}
STATE_DIR=$REPO/.devenv/state/msksd
WID=$(ls "$STATE_DIR/vms" 2>/dev/null | head -1)
for d in "$STATE_DIR/vms"/*; do [ "$(basename "$d")" != "" ] && WID=$(basename "$d"); done
# prefer the id msks itself reports for the workspace
if command -v msks >/dev/null 2>&1; then
    _id=$(msks ls 2>/dev/null | awk -v w="$WORKSPACE" '$1==w{print $2; exit}')
    [ -n "${_id:-}" ] && WID=$_id
fi
VMDIR="$STATE_DIR/vms/$WID"
STAMP=$(date +%Y%m%d-%H%M%S)
LOG=/home/chrism/649-retest/boot-$STAMP.log

echo "=== host ==="
uname -a
sudo dmesg | grep -iE "kvm \[1\]" | head -12
/usr/local/bin/cloud-hypervisor --version

echo "=== start workspace $WORKSPACE (vm $WID) ==="
msks start "$WORKSPACE" || exit 1

# Attach the serial console capture the moment the socket appears.
for i in $(seq 1 100); do [ -S "$VMDIR/console.sock" ] && break; sleep 0.2; done
socat -u UNIX-CONNECT:"$VMDIR/console.sock" - > "$LOG" 2>/dev/null < /dev/null &
SOCAT=$!

# Watch for success/failure markers for up to 8 minutes.
DEADLINE=$((SECONDS + 480))
VERDICT=unknown
while [ $SECONDS -lt $DEADLINE ]; do
    sleep 20
    if grep -qiE "sshd|login:|Reached target (multi-user|graphical)" "$LOG" 2>/dev/null; then VERDICT=BOOTED; break; fi
    if grep -qE "hard LOCKUP|rcu.*stall|hung_task|INFO: task" "$LOG" 2>/dev/null; then
        # lockup before real userspace = the #649 stall; early "Reached target"
        # lines are NOT userspace (that was the false-positive BOOTED)
        if ! grep -qiE "sshd|login:|Reached target (multi-user|graphical)" "$LOG"; then VERDICT=STALLED; break; fi
    fi
done

echo "=== verdict: $VERDICT (after $SECONDS s) ==="
wc -c "$LOG"
echo "--- markers ---"
grep -icE "systemd" "$LOG" 2>/dev/null || true
grep -iE "dhcp|sshd|login:|Reached target" "$LOG" 2>/dev/null | head -5
grep -E "hard LOCKUP|rcu|hung|NMI|Possible timer" "$LOG" 2>/dev/null | head -10
echo "--- tail ---"
tail -c 500 "$LOG" | tr -d '\r'

# Teardown: ask the daemon, then the VMM directly (a wedged guest ignores ACPI).
# NEVER pkill -f a pattern this script's own cmdline contains — pidfile, then -x.
kill $SOCAT 2>/dev/null
msks stop "$WORKSPACE" >/dev/null 2>&1
sleep 3
[ -f "$VMDIR/ch.pid" ] && kill "$(cat "$VMDIR/ch.pid")" 2>/dev/null
pkill -x cloud-hypervisor 2>/dev/null
sleep 2
echo "=== console log: $LOG ==="
