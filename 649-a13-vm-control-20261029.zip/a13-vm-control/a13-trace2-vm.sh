#!/usr/bin/env bash
# a13 on the VZ-nested control (Track D): same event set as the Asahi
# a13-trace2.sh round — kvm_ack_irq kvm_irq_line kvm_timer_update_irq
# kvm_wfx_arm64 vgic_update_irq_pending kvm_handle_sys_reg — during a
# QEMU KVM boot of the same guest kernel/initrd/cmdline/rootfs family.
# No set_event_pid filtering (the Asahi round's first two runs caught
# 12 events behind a stale pid filter; this arm leaves it off).
set -u
T=/sys/kernel/tracing
HERE=/home/chrism.guest/649-retest
STAMP=$(date +%Y%m%d-%H%M%S)
TRACE="$HERE/logs/a13-vm-trace-$STAMP.txt"
DIGEST="$HERE/logs/a13-vm-digest-$STAMP.txt"
mkdir -p "$HERE/logs"

EVENTS="kvm_ack_irq kvm_irq_line kvm_timer_update_irq kvm_wfx_arm64 \
vgic_update_irq_pending kvm_handle_sys_reg"

sudo bash -c "
  echo 0 > $T/tracing_on
  echo > $T/trace
  echo 0 > $T/events/enable
  cat $T/set_event_pid > $HERE/logs/.set_event_pid.bak 2>/dev/null || true
  echo > $T/set_event_pid 2>/dev/null || true
  for e in $EVENTS; do echo 1 > $T/events/kvm/\$e/enable 2>/dev/null; done
  echo 1 > $T/tracing_on
  echo \"armed: tracing_on=\$(cat $T/tracing_on)\"
"

echo "=== running qemu-ab.sh (KVM) under trace ==="
ACCEL=kvm CPU=host WATCH_SECS=300 bash "$HERE/qemu-ab.sh" 2>&1

sudo bash -c "echo 0 > $T/tracing_on; echo 0 > $T/events/enable; cp $T/trace '$TRACE'"
sudo chown chrism:chrism "$TRACE" 2>/dev/null

{
  echo "# a13 VM digest $STAMP"
  echo "## total trace events: $(wc -l < "$TRACE")"
  for e in $EVENTS; do printf "%-26s %s\n" "$e" "$(grep -c " $e:" "$TRACE")"; done
  echo
  echo "## guest sysreg reads seen by KVM (kvm_handle_sys_reg), by register"
  grep " kvm_handle_sys_reg:" "$TRACE" | grep -ioE "(ICC|CNTP|CNTV|CNTH|PMR)[A-Z0-9_]*" | sort | uniq -c | sort -rn | head -10
  echo
  echo "## IAR/EOI-specific lines (capped 15)"
  grep -iE " kvm_handle_sys_reg:.*(IAR|EOI)" "$TRACE" | head -15
  echo
  echo "## last 10 vgic pending asserts (capped)"
  grep " vgic_update_irq_pending:" "$TRACE" | tail -10
  echo
  echo "## wfx distinct PCs (top 4)"
  grep " kvm_wfx_arm64:" "$TRACE" | sed -E 's/.*(wfi|wfe) at: (\S+).*/\1 @ \2/' | sort | uniq -c | sort -rn | head -4
} > "$DIGEST"

echo "=== digest ==="
cat "$DIGEST"
echo "=== full trace: $TRACE ==="
