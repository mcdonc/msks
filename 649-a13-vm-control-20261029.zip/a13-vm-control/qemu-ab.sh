#!/usr/bin/env bash
# Track D (issue #649 course): qemu A/B on the VZ-nested VM's KVM.
# Same shape as the Asahi host's qemu-ab.sh, adapted:
#   - guest RAM 2048 (the VM has 8 GiB total; 8192 will not fit)
#   - no seed.img (no live workspace dir carries one; the seed only
#     feeds cloud-init, which the interrupt trace does not need)
#   - assets point at the VM's image store
set -u

ACCEL=${ACCEL:-kvm}
CPU=${CPU:-host}
IMGDIR=/home/chrism.guest/msks/.devenv/state/msksd/images/0c8dd9f41f4d1fa72391f5ad96d9e89c026cd568a234eed162d03c0848ec703f
KERNEL=${KERNEL:-$IMGDIR/kernel}
INITRD=${INITRD:-$IMGDIR/initrd}
ROOTFS=${ROOTFS:-$IMGDIR/rootfs.ext4}
HERE=/home/chrism.guest/649-retest
STAMP=$(date +%Y%m%d-%H%M%S)
LOG="$HERE/qemu-boot-$STAMP.log"
OUT="$HERE/qemu-stdout-$STAMP.log"
PIDFILE="$HERE/qemu.pid"

qemu-img create -f qcow2 -b "$ROOTFS" -F raw "$HERE/qemu-ab-overlay.qcow2" 10G >/dev/null

setsid qemu-system-aarch64 \
  -M virt,gic-version=3 -cpu $CPU -accel $ACCEL \
  -smp 2 -m 2048 \
  -kernel "$KERNEL" -initrd "$INITRD" \
  -append "console=ttyAMA0 root=/dev/vda rootfstype=ext4 rw" \
  -drive file="$HERE/qemu-ab-overlay.qcow2",if=virtio,format=qcow2 \
  -netdev user,id=n0 -device virtio-net-pci,netdev=n0 \
  -display none -monitor none -serial file:"$LOG" \
  >"$OUT" 2>&1 &
QPID=$!
echo "$QPID" > "$PIDFILE"

DEADLINE=$((SECONDS + ${WATCH_SECS:-300}))
VERDICT=unknown
while [ $SECONDS -lt $DEADLINE ]; do
    sleep 15
    kill -0 "$QPID" 2>/dev/null || { VERDICT=QEMU-DIED; break; }
    if grep -qiE "sshd|login:|Reached target (multi-user|graphical)" "$LOG" 2>/dev/null; then VERDICT=BOOTED; break; fi
    if grep -qE "hard LOCKUP|rcu.*stall|hung_task|INFO: task" "$LOG" 2>/dev/null; then
        if ! grep -qiE "sshd|login:|Reached target (multi-user|graphical)" "$LOG"; then VERDICT=STALLED; break; fi
    fi
done

echo "=== verdict: $VERDICT (after $SECONDS s, accel=$ACCEL cpu=$CPU) ==="
wc -c "$LOG" 2>/dev/null
echo "--- markers ---"
grep -icE "systemd" "$LOG" 2>/dev/null || true
grep -iE "dhcp|sshd|login:|Reached target (multi-user|graphical)" "$LOG" 2>/dev/null | head -8
echo "--- failure markers (count) ---"
grep -cE "hard LOCKUP|rcu_preempt|hung task|Call trace" "$LOG" 2>/dev/null || true
echo "--- tail ---"
tail -c 400 "$LOG" 2>/dev/null | tr -d '\r'

kill -- -"$QPID" 2>/dev/null
sleep 2
pkill -x qemu-system-aarch64 2>/dev/null
echo "=== console log: $LOG ==="
